import { Ad, AdBreak, AdDescription, AdsAPI } from 'react-native-theoplayer';
import { VegaPlayer } from '@dolby-optiview/vega';
import { DefaultEventDispatcher } from '../event/DefaultEventDispatcher';
import { LogixIMAWrapper } from '@logituit-rel/logix-ads-manager';
import { VegaPlayerConfiguration } from '../../../api/player/VegaPlayerConfiguration';
import { VegaPlayerEventMap } from '../THEOplayerAdapter.vega';
export declare class AdsAPIWrapper implements AdsAPI {
    private _player;
    private _dispatcher;
    private _config;
    private _logixAdsWrapper?;
    private _eventIds;
    private _isPlayingAd;
    private _adPaused;
    private _currentAd;
    private _currentAdBreak;
    constructor(_player: VegaPlayer, _dispatcher: DefaultEventDispatcher<VegaPlayerEventMap>, _config: VegaPlayerConfiguration | undefined);
    private addPlayerEventListeners;
    private removePlayerEventListeners;
    private onPlayerPlay;
    get paused(): boolean | undefined;
    playAd(): boolean;
    pauseAd(): boolean;
    private onPlayerTimeUpdate;
    private onPlayerEnded;
    private onVolumeChange;
    playing(): Promise<boolean>;
    skip(): void;
    currentAdBreak(): Promise<AdBreak>;
    currentAds(): Promise<Ad[]>;
    scheduledAdBreaks(): Promise<never[]>;
    schedule(_ad: AdDescription): void;
    destroy(): void;
    set logixAdsWrapper(logixAdManager: LogixIMAWrapper | null);
    private addLogixEventListeners;
    private removeLogixEventListeners;
    private onAddError;
    private onLog;
    private onAdBreakFetchError;
    private onLoaded;
    private onAdMetadata;
    /**
     * Dispatched when the ad starts playing.
     */
    private onStarted;
    /**
     * Dispatched when the ad completes playing.
     */
    private onComplete;
    private onAdPaused;
    private onAdPlaying;
    private onContentPauseRequested;
    private onContentResumeRequested;
    private onFirstQuartile;
    private onMidpoint;
    private onThirdQuartile;
    private onBuffering;
    private onSkipped;
    private onImpression;
    private onClicked;
    private forwardEvent;
}
//# sourceMappingURL=AdsAPIWrapper.d.ts.map