import type { SdkVersions } from 'react-native-theoplayer';
import { version as nativeVersionString } from '@dolby-optiview/vega';
import manifest from '../../manifest.json';

export const sdkVersions = async (): Promise<SdkVersions> => {
    const rnVersionString = manifest.version ?? 'NA';
    return {
        rn: rnVersionString,
        native: nativeVersionString
    };
};
