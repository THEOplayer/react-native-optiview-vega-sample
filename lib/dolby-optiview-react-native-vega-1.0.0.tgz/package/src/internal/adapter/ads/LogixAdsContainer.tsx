import { AdsContainer, LogixIMAWrapper } from '@logituit-rel/logix-ads-manager';
import React, { useCallback, useEffect, useState } from 'react';
import { AdEvent, ErrorEvent, PlayerEventType } from 'react-native-theoplayer';
import { THEOplayer } from '../../../api/THEOplayer';
import { extractAdTagUrl, INVALID_AD, resolveAdTimeOffset } from './LogixAdsAdapter';
import { DefaultAdEvent } from '../event/PlayerEvents';
import { AdEventType } from 'react-native-theoplayer/src/api/event/AdEvent';
import { StyleSheet, View } from 'react-native';

export interface AdsManagerProps {
    player: THEOplayer | undefined;
}

export const LogixAdsContainer = (props: AdsManagerProps) => {
    const logixAdsManager = React.useRef<LogixIMAWrapper | null>(null);
    const firstPlay = React.useRef<boolean>(false);
    const [isPlayingAds, setIsPlayingAds] = useState(false);
    const [adsContainerKey, setAdsContainerKey] = useState(0);
    const currentAdsContainerKey = React.useRef(0);
    const managerLoaded = React.useRef(false);
    const [adTagUrl, setAdTagUrl] = useState<string | undefined>(undefined);
    const pausedForReadiness = React.useRef(false);
    const adRequested = React.useRef(false);
    const contentEnded = React.useRef(false);

    const resumeContent = useCallback(() => {
        if (pausedForReadiness.current) {
            pausedForReadiness.current = false;
            if (!contentEnded.current) {
                props.player?.play();
            }
        }
    }, [props.player]);

    useEffect(() => {
        const onSourceChange = () => {
            firstPlay.current = false;
            managerLoaded.current = false;
            adRequested.current = false;
            contentEnded.current = false;
            setAdTagUrl(undefined);
            pausedForReadiness.current = false;
            setIsPlayingAds(false);
            currentAdsContainerKey.current += 1;
            setAdsContainerKey(currentAdsContainerKey.current); // Increment key to remount AdsContainer
        };

        const maybeRequestAd = () => {
            const player = props.player;
            if (!player || !firstPlay.current || adRequested.current || (player.paused && !contentEnded.current)) {
                return;
            }
            // Logix can only handle one ad tag URL, so take first ad.
            const ad = player.source?.ads?.[0];
            if (!ad) {
                return;
            }
            const type = typeof ad.sources === 'object' ? ad.sources.type : undefined;
            const currentTimeSeconds = player.currentTime / 1000;
            const durationSeconds = player.duration / 1000;
            const offset = resolveAdTimeOffset(type === 'vmap' || type === 'adrule' ? undefined : ad.timeOffset, durationSeconds);
            const due = offset === 'end'
                ? contentEnded.current
                : offset !== undefined && Number.isFinite(currentTimeSeconds) && currentTimeSeconds >= offset;
            if (!due) {
                return;
            }
            const tag = extractAdTagUrl(ad.sources);
            if (tag) {
                adRequested.current = true;
                pausedForReadiness.current = true;
                setAdTagUrl(tag);
                if (!contentEnded.current) {
                    player.pause();
                }
            }
        };

        const onPlay = () => {
            /**
             * If the adTagUrl is passed to the AdsContainer as a property, play-out would start immediately.
             * Instead, pass it once the first play is triggered.
             */
            firstPlay.current = true;
            maybeRequestAd();

            // Keep content paused until IMA takes over, confirms no break is due, or reports an ad failure.
            if (pausedForReadiness.current && !props.player?.paused) {
                props.player?.pause();
            }
        };

        const onEnded = () => {
            contentEnded.current = true;
            maybeRequestAd();
        };

        const onAdEvent = (event: AdEvent) => {
            if ([AdEventType.AD_BREAK_BEGIN, AdEventType.AD_BEGIN, AdEventType.AD_BREAK_END].includes(event.subType)) {
                // IMA now owns playback: do not let its playing events trigger our startup pause again.
                // Clearing on break-end also allows normal content resume when no ad could start.
                pausedForReadiness.current = false;
            }
            if ([AdEventType.AD_BREAK_BEGIN, AdEventType.AD_BEGIN].includes(event.subType)) {
                setIsPlayingAds(true);
            }
            if ([AdEventType.AD_BREAK_END, AdEventType.AD_SKIP, AdEventType.AD_ERROR].includes(event.subType)) {
                setIsPlayingAds(false);
            }
        };

        const onPlayerError = (event: ErrorEvent) => {
            // AdsAPIWrapper.onAddError maps Logix ad failures to "10000", unlike content or license errors.
            // If we still own the readiness pause, a failed ad must not leave content blocked indefinitely.
            // resumeContent is a no-op after ad takeover or recovery, and never restarts ended content.
            if (event.error.errorCode === '10000') {
                resumeContent();
            }
        };

        props.player?.addEventListener(PlayerEventType.ERROR, onPlayerError);
        props.player?.addEventListener(PlayerEventType.PLAYING, onPlay);
        props.player?.addEventListener(PlayerEventType.SOURCE_CHANGE, onSourceChange);
        props.player?.addEventListener(PlayerEventType.AD_EVENT, onAdEvent);
        props.player?.addEventListener(PlayerEventType.TIME_UPDATE, maybeRequestAd);
        props.player?.addEventListener(PlayerEventType.DURATION_CHANGE, maybeRequestAd);
        props.player?.addEventListener(PlayerEventType.ENDED, onEnded);

        return () => {
            props.player?.setAdsManager(null);
            props.player?.removeEventListener(PlayerEventType.ERROR, onPlayerError);
            props.player?.removeEventListener(PlayerEventType.PLAYING, onPlay);
            props.player?.removeEventListener(PlayerEventType.SOURCE_CHANGE, onSourceChange);
            props.player?.removeEventListener(PlayerEventType.AD_EVENT, onAdEvent);
            props.player?.removeEventListener(PlayerEventType.TIME_UPDATE, maybeRequestAd);
            props.player?.removeEventListener(PlayerEventType.DURATION_CHANGE, maybeRequestAd);
            props.player?.removeEventListener(PlayerEventType.ENDED, onEnded);
            firstPlay.current = false;
        };
    }, [props.player, resumeContent]);

    useEffect(() => {
        return () => {
            // eslint-disable-next-line react-hooks/exhaustive-deps
            logixAdsManager.current?.destroy();
        };
    }, []);

    if (!props.player || !adTagUrl) {
        return null;
    }

    return (<View style={isPlayingAds ? styles.adContainer : styles.collapsedAdContainer}>
        <AdsContainer
            key={adsContainerKey}
            ref={logixAdsManager}
            adTagUrl={adTagUrl}
            onError={(event) => {
                if (adsContainerKey !== currentAdsContainerKey.current) {
                    return;
                }
                console.warn(`Logix Ads Manager error: ${event.getError().getErrorCode()} - ${event.getError().getMessage()}`);
                props.player?.dispatchEvent(new DefaultAdEvent(
                    AdEventType.AD_ERROR,
                    INVALID_AD
                ));
                resumeContent();
            }}
            onManagerLoaded={async () => {
                const manager = logixAdsManager.current;
                if (adsContainerKey !== currentAdsContainerKey.current || !manager || managerLoaded.current) {
                    return;
                }
                props.player?.setAdsManager(manager);
                managerLoaded.current = true;
                await Promise.resolve();
                if (adsContainerKey !== currentAdsContainerKey.current || logixAdsManager.current !== manager) {
                    return;
                }
                // start() only queues a WebView command. Resuming now would flash content before IMA pauses it.
                void manager.adsManager.start();
                const result = await manager.adsManager.getCuePoints();
                if (adsContainerKey !== currentAdsContainerKey.current || logixAdsManager.current !== manager) {
                    return;
                }
                // IMA returns an empty array for an unscheduled VAST ad/pod, not for "no ads". Keep its startup pause.
                // Zero or elapsed cues are due now; -1 is postroll. Only an explicit future-only schedule lets content run.
                // With an unknown schedule, wait for ad takeover, break-end, or the ad-error recovery path instead.
                const currentTimeSeconds = (props.player?.currentTime ?? 0) / 1000;
                if (result?.cuePoints?.length && result.cuePoints.every(cue => cue === -1 || (cue > 0 && cue > currentTimeSeconds))) {
                    resumeContent();
                }
            }}
        />
    </View>);
};

const styles = StyleSheet.create({
    collapsedAdContainer: {
        height: 0,
        width: 0,
        zIndex: -1,
        overflow: 'hidden'
    },
    adContainer: {
        ...StyleSheet.absoluteFillObject,
        zIndex: 100
    }
});
