import { AdEvent as LogixAdEvent, } from '@logituit-rel/logix-ads-manager';
import { Ad, AdBreak, AdDescription, AdSource } from 'react-native-theoplayer';

export const INVALID_ADBREAK: AdBreak = {
    integration: 'google-ima',
    ads: undefined,
    id: undefined,
    timeOffset: 0,
    maxDuration: undefined,
    maxRemainingDuration: undefined
};

export const INVALID_AD: Ad = {
    integration: 'google-ima',
    id: undefined,
    adSystem: undefined,
    type: 'linear',
    width: undefined,
    height: undefined,
    companions: [],
    skipOffset: undefined,
    creativeId: undefined,
    universalAdIds: [],
    clickThrough: undefined,
    adBreak: INVALID_ADBREAK
};

export function fromLogixAd(event: LogixAdEvent, currentAdBreak: AdBreak | undefined = undefined): Ad {
    const logixAd = event.getAd();
    return {
        adSystem: logixAd?.getAdSystem(),
        integration: 'google-ima',
        type: 'linear',
        id: logixAd?.getAdId(),
        adBreak: currentAdBreak ?? INVALID_ADBREAK,
        duration: logixAd?.getDuration(),
        width: logixAd?.getWidth(),
        height: logixAd?.getHeight(),
        resourceURI: logixAd?.getMediaUrl() ?? undefined,
        clickThrough: undefined,
        companions: [],
        skipOffset: logixAd?.getSkipTimeOffset(),
        creativeId: logixAd?.getCreativeId(),
        universalAdIds: logixAd?.getUniversalAdIds() ?? []
    };
}

export function fillAdBreakWithLogixPodInfo(adBreak: AdBreak | undefined, event: LogixAdEvent): AdBreak {
    const adPod = event.getAd()?.getAdPodInfo();
    return {
        ...INVALID_ADBREAK,
        ...adBreak,
        timeOffset: adPod?.getTimeOffset() ?? 0,
        maxDuration: adPod?.getMaxDuration() ?? 0,
    }
}

export function adBreakFromCuePoints(cuePoints: number[]): AdBreak | undefined {
    if (cuePoints.length === 0) {
        return undefined;
    }
    const adBreak: AdBreak = {
        ...INVALID_ADBREAK,
        ads: [],
        timeOffset: cuePoints[0],
    }
    adBreak.ads = (cuePoints.map(_point => ({
        ...INVALID_AD,
        adBreak,
    })));
    return adBreak;
}

export const extractAdTagUrl = (sources?: string | AdSource): string | undefined => {
    if (typeof sources === 'string') {
        return sources;
    }
    return sources?.src;
};

export function resolveAdTimeOffset(offset: AdDescription['timeOffset'], duration: number): number | 'end' | undefined {
    if (offset === undefined || offset === 'start') {
        return 0;
    }
    if (offset === 'end') {
        return 'end';
    }
    let seconds: number;
    if (typeof offset === 'number') {
        seconds = offset;
    } else if (/^\d+(?:\.\d+)?%$/.test(offset)) {
        const percentage = parseFloat(offset);
        if (percentage > 100 || !Number.isFinite(duration) || duration <= 0) {
            return undefined;
        }
        seconds = duration * percentage / 100;
    } else {
        const timestamp = /^(\d{2,}):([0-5]\d):([0-5]\d(?:\.\d{1,3})?)$/.exec(offset);
        if (!timestamp) {
            return undefined;
        }
        seconds = Number(timestamp[1]) * 3600 + Number(timestamp[2]) * 60 + Number(timestamp[3]);
    }
    return Number.isFinite(seconds) && seconds >= 0 && (!Number.isFinite(duration) || duration < 0 || seconds <= duration)
        ? seconds
        : undefined;
}
