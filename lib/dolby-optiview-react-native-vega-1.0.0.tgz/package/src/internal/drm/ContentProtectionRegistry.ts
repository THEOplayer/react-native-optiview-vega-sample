import type { ContentProtectionAPI, ContentProtectionIntegrationFactory, KeySystemId } from 'react-native-theoplayer';
import {
    registerContentProtectionIntegration,
    ContentProtectionIntegrationFactory as NativeContentProtectionIntegrationFactory,
    KeySystemId as NativeKeySystemId
} from '@dolby-optiview/vega';

export class WebContentProtectionRegistry implements ContentProtectionAPI {
    registerContentProtectionIntegration(integrationId: string, keySystem: KeySystemId, integrationFactory: ContentProtectionIntegrationFactory): void {
        registerContentProtectionIntegration(
            integrationId,
            keySystem as NativeKeySystemId,
            integrationFactory as NativeContentProtectionIntegrationFactory
        );
    }
}

export const ContentProtectionRegistry = new WebContentProtectionRegistry();
