# Logix Google IMA Ads Manager

## Logix Ads Manager enables support for Google IMA Ads (client-side) for VOD content.  

Our Logix Ads Manager uses IMA SDK for HTML5 and display Ads using a WebView in a Vega Application.

## Features
- Supports **Pre-roll, Mid-roll, Post-roll, and Bumper Ads** for VOD content  
- Supports for All methods listed in the Google IMA HTML5 Ad Interface documentation
- Ability to listen to all IMA Ad Events like :
  - `CONTENT_PAUSE_REQUESTED`
  - `CONTENT_RESUME_REQUESTED` etc.
- Ability to listen to all AdError events
- Provides TypeScript support

## Documentation
For the complete documentation, please visit and fill out the form at: 
[**LogixAds Manager – Logituit**](https://logituit.com/logixads-manager/)

## Support

For general help and support, bug report or feature request, please reach out to our support team at: **keplersupport@logituit.com**

Our team will be happy to assist you.
